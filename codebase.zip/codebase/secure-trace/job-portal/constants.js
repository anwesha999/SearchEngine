module.exports = {
};

module.exports.LOG_LEVEL = {
    ERROR: 'ERROR',
    DEBUG: 'DEBUG',
    INFO: 'INFO'
};